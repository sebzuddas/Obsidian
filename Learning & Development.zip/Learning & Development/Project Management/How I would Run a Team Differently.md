1. When doing bids, make sure the whole team has a clear understanding of:
	1. What we are proposing for that bid, that isn't just regurgitating what has been set out by the rfp
	2. Ensure the whole team has contributed to formulating the offer in the same session (max 60 mins, aim for 30 mins). 
2. An anonymous 'idea box' that ensures the team feel they can communicate, anonymously, any ideas they may have to improve the everyday functioning of the team. 
3. A daily short standup, where everyone has 2 minutes to summarise what they are going to do and where they may need help. 
4. A board of 'solutions to hard things', where we have to write up solutions to previously hard problems, tagged with who solved the problem. This gives opportunity to synthesize the learning of solving the hard problem, whilst simultaneously enabling the team to share the learning. 