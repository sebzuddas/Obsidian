[Link to a subheader in another note - Feature archive - Obsidian Forum](https://forum.obsidian.md/t/link-to-a-subheader-in-another-note/2755/2)

