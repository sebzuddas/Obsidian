---
aliases:
  - vector
  - Vector
  - vectors
tags:
  - maths
  - engineering
---
