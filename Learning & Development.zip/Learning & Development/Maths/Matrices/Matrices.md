---
aliases:
  - matrix
  - matrices
  - Matrix
---
Typically denoted by a capital letter $X$, a matrix with $m$ rows and $n$ columns is defined as $X\in \mathbb R^{m \times n}$. 

