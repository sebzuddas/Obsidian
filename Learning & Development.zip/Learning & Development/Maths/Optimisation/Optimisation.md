---
aliases:
  - optimal
  - optimisation
  - Optimization
  - optimization
---
Optimisation looks at minimising defined objective function, which may be constrained or unconstrained. 

---
# Objective Functions

^a835ed

---
