Loss functions are a subset of [[Optimisation#^a835ed|Objective functions]]
