---
aliases:
  - SoS
---
Defined originally by [Kotov 1997](https://shiftleft.com/mirrors/www.hpl.hp.com/techreports/97/HPL-97-124.pdf)
A [[System]] of systems is a system comprised of systems. 