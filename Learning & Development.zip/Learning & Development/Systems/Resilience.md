---
aliases:
  - resilient
  - resilience
  - Resilient
---
