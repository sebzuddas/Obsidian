---
aliases:
  - system
  - systems
  - Systems
tags:
  - system
  - complexity
---
