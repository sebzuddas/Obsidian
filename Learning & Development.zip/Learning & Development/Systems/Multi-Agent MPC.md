A combination of [[Agent-based Modelling (ABM)|ABM]] and [[Model Predictive Control (MPC)|MPC]]. 
https://digital.csic.es/bitstream/10261/30146/1/Distributed%20MPC.pdf
