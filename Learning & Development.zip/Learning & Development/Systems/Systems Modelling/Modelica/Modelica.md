---
aliases:
  - Modelica
  - OpenModelica
  - open modelica
  - Open Modelica
  - Open modelica
  - openmodelica
---
[Eradity | Digital transformation that matters](https://www.eradity.com/) - Digital twins with system simulation underneath. 

Modelica is acausal, meaning equations can be interpreted by the compiler in the form of $xy = y+x$. 

