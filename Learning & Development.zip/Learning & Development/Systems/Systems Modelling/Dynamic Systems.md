---
aliases:
  - dynamics
  - Dynamics
  - SD
  - system dynamics
  - Dynamic Systems
---
Dynamic Systems are typically represented by [[Ordinary Differential Equations (ODEs)]]
