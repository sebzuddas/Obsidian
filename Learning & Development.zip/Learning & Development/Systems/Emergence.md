---
aliases:
  - emergence
  - Emergent
  - emergent
---
