---
aliases:
  - state space
  - State space
  - State Space
---

# Model Form

$\dot{\vec{x}} = A\cdot \vec x + B \cdot \vec u$
$\vec z = C \cdot \vec x + D \cdot \vec u$ ^847543

---

