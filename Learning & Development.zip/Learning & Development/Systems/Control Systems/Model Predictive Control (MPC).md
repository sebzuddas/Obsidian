---
aliases:
  - MPC
  - Model-predictive Control
  - model-predictive control
  - model predictive control
---


Following a [[State-space Control|state space]] model of the form:
![[State-space Control#^847543]]

