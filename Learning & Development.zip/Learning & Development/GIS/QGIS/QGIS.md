---
aliases:
  - qgis
  - Quantum-GIS
---
An open source software for manipulating [[GIS|GIS]] data, built on C++. 
