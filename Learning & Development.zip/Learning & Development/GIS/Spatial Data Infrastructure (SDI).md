---
aliases:
  - spatial data infrastructure
  - Spatial data infrastructure
  - Spatial-data infrastructure
  - spatial-data infrastructure
  - SDI
---
A subset of [[Data Infrastructure]], Spatial Data Infrastructure (SDI) is an approach to ensure the management of spatial data within an organisation is conducive to the objectives of the organisation. This is typically realised through appropriate [[Data Governance]] methods. 