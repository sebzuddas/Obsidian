Energy is the amount of [[work]] done or [[heat]] transferred over time. 
