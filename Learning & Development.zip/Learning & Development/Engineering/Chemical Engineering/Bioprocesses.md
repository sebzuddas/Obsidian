---
tags:
  - complexity
  - engineering
aliases:
  - bioprocess
  - Bioprocess
  - bioprocesses
---
[[Cells]] as factories. 