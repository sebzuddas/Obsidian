Expert systems were the first examples of applied [[Artificial Intelligence]]. They strive to reason like a human being, using a combination of a knowledge base, and an [[Inference Engine]]. The knowledge base is made up of knowledge from experts, whereas the [[Inference Engine]] draws on the knowledge base using rules to apply the knowledge to the specific problem. 
```mermaid

```