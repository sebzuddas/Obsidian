---
aliases:
  - RL
  - Reinforcement learning
  - reinforcement learning
---
Reinforcement learning is a subset of [[Machine Learning]], and is based on using policy. 