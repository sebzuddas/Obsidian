---
aliases:
  - Amazon EC2
  - awsEC2
  - ec2
  - EC2 instance
---
