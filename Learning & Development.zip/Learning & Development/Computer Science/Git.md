---
aliases:
  - git
---
# Common Git Commands:
